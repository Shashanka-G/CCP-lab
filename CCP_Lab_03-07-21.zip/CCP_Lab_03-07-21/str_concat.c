#include<stdio.h>
int getlenght(char str[]){
    int i=0;
    while(str[i]!='\0')
        i++;
    return i;
}
main(){
    char str1[20],str2[20],str3[40];int i=0,j=0;
    printf("Enter first string:");
    gets(str1);
    printf("Enter second string:");
    gets(str2);
    while(str1[i]!='\0'){
        str3[j]=str1[i];
        i++;j++;
    }
    i=0;
    while(str2[i]!='\0'){
        str3[j]=str2[i];
        i++;j++;
    }
    str3[j]='\0';
    printf("Concatinated string is:");
    for(i=0;i<j;i++)
        printf("%c",str3[i]);
    printf("\nlength is %d",getlenght(str3));

}
