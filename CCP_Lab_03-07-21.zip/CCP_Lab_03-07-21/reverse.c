#include<stdio.h>
int getlength(char str[]){
    int i=0;
    while(str[i]!='\0')
        i++;
    return i;
}
main(){
    char str[25],rev[25],len,i;
    printf("Enter a string:");
    gets(str);
    len=getlength(str);
    for(i=0;i<len;i++){
        rev[i]=str[len-1-i];
    }
    printf("Revesed string is:");
    for(i=0;i<len;i++)
        printf("%c",rev[i]);
}
