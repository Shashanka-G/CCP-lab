#include<stdio.h>
main(){
    int mat1[5][5],mat2[5][5],mat3[5][5],i,j,n;
    printf("*****Addition of two matrices*****\n");
    printf("Enter 1 to add 2X2 matrix\n");
    printf("Enter 2 to add 3X3 matrix\n");
    printf("Enter 3 to add 4X4 matrix\n");
    printf("Enter choice:");
    scanf("%d",&n);
    printf("Enter elements of matrix 1\n");
    for(i=0;i<n+1;i++){
        for(j=0;j<n+1;j++){
            printf("Enter mat1[%d][%d]:",i,j);
            scanf("%d",&mat1[i][j]);
        }
    }
    printf("Enter elements of matrix 2\n");
    for(i=0;i<n+1;i++){
        for(j=0;j<n+1;j++){
            printf("Enter mat2[%d][%d]:",i,j);
            scanf("%d",&mat2[i][j]);
        }
    }
    for(i=0;i<n+1;i++){
        for(j=0;j<n+1;j++){
            mat3[i][j]=mat1[i][j]+mat2[i][j];
        }
    }
    printf("Addition of two matrices is\n");
    for(i=0;i<n+1;i++){
        for(j=0;j<n+1;j++){
            printf("|%d",mat3[i][j]);

        }
        printf("|");
        printf("\n");
    }

}
