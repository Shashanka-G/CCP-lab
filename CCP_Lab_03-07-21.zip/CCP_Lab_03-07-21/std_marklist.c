#include<stdio.h>
main(){
    int mrklis[4][3],i,j,big;
    printf("Enter the details of each student\n");
    for(i=0;i<4;i++){
        for(j=0;j<3;j++){
            printf("Enter marks in Subject%d of Student%d:",j+1,i+1);
            scanf("%d",&mrklis[i][j]);
        }
    }
    big=mrklis[0][0];
    printf("Students\t   subject1\t   subject2\t   subject3\n");
    for(i=0;i<4;i++){
        printf("Student%d",i+1);
        for(j=0;j<3;j++){
            printf("\t\t%d",mrklis[i][j]);
        }
        printf("\n");
    }
    for(j=0;j<3;j++){
        for(i=0;i<4;i++){
            if(mrklis[i][j]>big)
                big=mrklis[i][j];
        }
    printf("Highest marks in Subject%d is %d\n",j+1,big);
    big=0;
    }

}
