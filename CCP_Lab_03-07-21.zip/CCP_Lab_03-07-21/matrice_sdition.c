#include<stdio.h>
main(){
    int rows,columns,i,j,mat1[10][10],mat2[10][10],mat3[10][10];
    printf("Enter the number of rows:");
    scanf("%d",&rows);
    printf("Enter the number of columns:");
    scanf("%d",&columns);
    printf("Enter the elements of first matrix:\n");
    for(i=0;i<rows;i++){
        for(j=0;j<columns;j++){
            printf("mat1[%d][%d]:",i,j);
            scanf("%d",&mat1[i][j]);
        }
    }
    printf("Enter the elements of second matrix:\n");
    for(i=0;i<rows;i++){
        for(j=0;j<columns;j++){
            printf("mat2[%d][%d]:",i,j);
            scanf("%d",&mat2[i][j]);
        }
    }
    printf("Addition of  two matrices is :\n");
    for(i=0;i<rows;i++){
        for(j=0;j<columns;j++){
            mat3[i][j]=mat1[i][j]+mat2[i][j];
        }
    }
    for(i=0;i<rows;i++){
        for(j=0;j<columns;j++){
            printf("%d\t",mat3[i][j]);
        }
        printf("\n");
    }
}
