#include<stdio.h>
int getlenght(char str[]){
    int i=0;
    while(str[i]!='\0')
        i++;
    return i;
}
main(){
    char str1[15],str2[15],len1,i;
    printf("Enter the first string:");
    gets(str1);
    len1=getlenght(str1);
    for(i=0;i<len1;i++)
        str2[i]=str1[i];
    i++;
    str2[i]='\0';
    printf("copied string is:");
    for(i=0;i<len1;i++)
        printf("%c",str2[i]);
    printf("\nlength of copied string is: %d",getlenght(str2));
}
