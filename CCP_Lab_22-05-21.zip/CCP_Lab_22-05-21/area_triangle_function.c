#include<stdio.h>
#include<math.h>
float find_area(float a,float b, float c);
main(){
    float a,b,c,Area;
    printf("Enter sides:");
    scanf("%f %f %f",&a,&b,&c);
    Area=find_area(a,b,c);
    printf("Area is: %f",Area);

}
float find_area(float a,float b, float c)
{
    float s,area;
    s=(a+b+c)/2;
    area=sqrt(s*(s-a)*(s-b)*(s-c));
    return area;
}
