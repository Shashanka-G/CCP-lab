#include<stdio.h>
float avg_3_nums(float a,float b,float c);
main(){
    float x,y,z,avg;
    printf("Enter three numbers:");
    scanf("%f %f %f",&x,&y,&z);
    avg=avg_3_nums(x,y,z);
    printf("Average is: %f",avg);
}
float avg_3_nums(float a,float b,float c)
{
    float average=(a+b+c)/3;
    return average;
}
