#include<stdio.h>
main(){
    int i,arr[10],key,pos,flag=0;
    for(i=0;i<10;i++){
        printf("Enter array[%d]:",i);
        scanf("%d",&arr[i]);
    }
    printf("Enter the you want to search:");
    scanf("%d",&key);
    for(i=0;i<10;i++){
        if(arr[i]==key){
            pos=i;
            flag=1;
            break;
        }
    }
    if(flag==1)
    printf("%d is found at index:%d",key,pos);
    else
        printf("%d is not found in the array",key);
}
