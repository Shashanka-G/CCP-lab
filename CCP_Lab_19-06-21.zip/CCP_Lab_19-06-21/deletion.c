#include<stdio.h>
main(){
    int arr[10],loc,n,i,j;
    printf("Enter the number of elements in the array:");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        printf("Enter array[%d]:",i);
        scanf("%d",&arr[i]);
    }

    printf("Enter the position from which element is to be deleted:");
    scanf("%d",&loc);
    for(j=loc-1;j<n;j++)
        arr[j]=arr[j+1];
    for(i=0;i<n-1;i++)
        printf("|%d",arr[i]);printf("|");
}
