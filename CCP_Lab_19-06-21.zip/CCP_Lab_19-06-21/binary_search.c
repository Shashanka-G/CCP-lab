#include<stdio.h>
main(){
    int arr[10],key,low=0,high=9,mid,pos,i;
    for(i=0;i<10;i++){
        printf("Enter array[%d]:",i);
        scanf("%d",&arr[i]);
    }
    printf("Enter the you want to search:");
    scanf("%d",&key);
    mid=(low+high)/2;
    while(low<=high){
        if(arr[mid]==key){
            printf("%d is found at index %d",key,mid);
            break;
        }else if(arr[mid]<key){
            low=mid;
            mid=(low+high)/2;
        }
        else{
            high=mid;
            mid=(low+high)/2;
        }
        }
    }
