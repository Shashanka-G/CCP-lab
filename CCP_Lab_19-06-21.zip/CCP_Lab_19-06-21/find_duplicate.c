#include<stdio.h>
main(){
    int arrsize=10,i,j,flag=0;
    int array[arrsize];
    for(i=0;i<arrsize;i++){
        printf("Enter array[%d]:",i);
        scanf("%d",&array[i]);
    }
    for(i=0;i<arrsize-2;i++){
        for(j=i+1;j<arrsize;j++){
            if(array[i]==array[j]){
                flag=1;
                break;
            }
        }
    }
    if(flag==1)
        printf("Array  contains duplicate");
    else
        printf("Array does not contain duplicates");
}
