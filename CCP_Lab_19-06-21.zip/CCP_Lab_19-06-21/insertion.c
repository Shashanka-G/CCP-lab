#include<stdio.h>
main(){
    int arr[5],i,n,pos,key;
    for(i=0;i<5;i++){
        printf("Enter arr[%d]:",i);
        scanf("%d",&arr[i]);
    }
    printf("Enter the element which you have to insert:");
    scanf("%d",&key);
    printf("Enter the position at which you have to insert:");
    scanf("%d",&pos);
    for(i=5;i>pos;i--){
        arr[i]=arr[i-1];
    }
    arr[pos]=key;
    for(i=0;i<=5;i++)
        printf("|%d",arr[i]);printf("|");
}
