#include<stdio.h>
main(){
    int i,large,large_pos,small,small_pos,n,arr[10],temp;
    for(i=0;i<10;i++){
        printf("Enter array[%d]:",i);
        scanf("%d",&arr[i]);
    }
    large=arr[0];
    small=arr[0];
    for(i=1;i<10;i++){
        if(arr[i]>large){
            large=arr[i];
            large_pos=i;
        }
    }
    for(i=1;i<10;i++){
        if(arr[i]<small){
            small=arr[i];
            small_pos=i;
        }
    }
    printf("large=%d ,small=%d ,large_position = %d,small_position=%d",large,small,large_pos,small_pos);
    printf("\nArray before swapping large and small is:");
    for(i=0;i<10;i++){
            printf("|%d",arr[i]);}
    printf("|");
    temp=small;
    arr[small_pos]=arr[large_pos];
    arr[large_pos]=temp;
    printf("\nArray after swapping large and small is:");
    for(i=0;i<10;i++){
            printf("|%d",arr[i]);}
    printf("|");

}
