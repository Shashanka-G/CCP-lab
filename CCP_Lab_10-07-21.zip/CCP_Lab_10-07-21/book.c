#include<stdio.h>

main(){
    typedef struct{
        char title[30];
        char author[30];
        int price;
        int pages;
        char date[20];
    }Book;
    Book book[3];
    float high_price;
    for(int i=0;i<3;i++){
        printf("Enter details of book %d\n",i+1);
        printf("Enter title:");
        gets(book[i].title);
        printf("Enter author name:");
        gets(book[i].author);
        printf("Enter date of publication:");
        gets(book[i].date);
        printf("Enter price:");
        scanf("%d",&book[i].price);
        printf("Enter no.of pages:");
        scanf("%d",&book[i].pages);
        fflush(stdin);
    }
    high_price=book[0].price;
    int track=0;
    for(int i=0;i<3;i++){
        if(book[i].price>high_price){
            high_price=book[i].price;
            track=i;
        }
    }
    printf("Book %d has highest price and its details as follows\n",track+1 );
    printf("Title:%s\n",book[track].title);
    printf("Author:%s\n",book[track].author);
    printf("Price:%d\n",book[track].price);
    printf("Date of publication:%s\n",book[track-1].date);
    printf("No of pages:%d\n",book[track].pages);
}
