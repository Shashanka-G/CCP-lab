#include<stdio.h>
main(){
    FILE *fp,*fp1;char extract,entry[10];
    fp=fopen("D:\\Users\\pushpa\\Desktop\\labfiles\\BMSCE.txt","w");
    if(fp==NULL){
        printf("file couldnt be opened");
        exit(1);
    }
    fflush(stdin);
    printf("Enter the data:");
    gets(entry);
    fputs(entry,fp);
    fclose(fp);

    fp1=fopen("D:\\Users\\pushpa\\Desktop\\labfiles\\BMSCE.txt","r");
    extract=fgetc(fp1);
    while(extract!=EOF){
        printf("%c",extract);
        extract=fgetc(fp1);
    }
    fclose(fp1);
}
