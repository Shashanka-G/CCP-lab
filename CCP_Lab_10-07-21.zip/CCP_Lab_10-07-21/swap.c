#include<stdio.h>
void swap(int *x, int *y){
    int temp;
    temp=*x;
    *x=*y;
    *y=temp;
}
main(){
    char m,n;
    printf("Enter two numbers:");
    scanf("%c %c",&m,&n);
    printf("Before swapping: %c %c\n",m,n);
    swap(&m,&n);
    printf("After swapping: %c %c",m,n);
}
