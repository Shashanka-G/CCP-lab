#include<stdio.h>
main(){
    int m,n,*p1,*p2;float div;
    p1=&m;p2=&n;
    printf("Enter first number:");
    scanf("%d",p1);
    printf("Enter second number:");
    scanf("%d",p2);
    printf("Sum:%d+%d = %d\n",*p1,*p2,*p1+*p2);
    printf("Difference:%d-%d=%d\n",*p1,*p2,*p1-*p2);
    printf("Product:%dX%d=%d\n",*p1,*p2,*p1**p2);
    if(*p2==0)
        printf("Division cannot be done\nZero division error");
    else{
        div=((float)*p1)/ *p2;
        printf("Division:%d/%d=%.2f",*p1,*p2,div);
    }

}
