#include<stdio.h>
#include<math.h>

float get_roots(float a,float b,float c,float del){
    float r1,r2;
    if (del<0)
        printf("Roots are  imaginary");
    else if (del>0){
        printf("Roots are real and distinct\n");
        r1=(-b+sqrt(del))/(2*a);
        r2=(-b-sqrt(del))/(2*a);
        printf("Rots are %f and %f",r1,r2);
    }else{
        printf("Roots are real and equal\n");
        r1=-b/(2*a);
        printf("Root=%f",r1);
}
}
main(){
    float a,b,c,del;
    printf("Enter the coefficient of a:");
    scanf("%f",&a);
    printf("Enter the coefficient of b:");
    scanf("%f",&b);
    printf("Enter the coefficient of c:");
    scanf("%f",&c);
    del=(b*b)-(4*a*c);
    get_roots(a,b,c,del);

}
