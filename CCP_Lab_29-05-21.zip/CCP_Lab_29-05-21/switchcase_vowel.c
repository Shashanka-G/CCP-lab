#include<stdio.h>
#include<ctype.h>
void check_for_vowel(char ltr){
    switch(ltr){
        case 'a':
        case 'A':
        case 'e':
        case 'E':
        case 'i':
        case 'I':
        case 'o':
        case 'O':
        case 'u':
        case 'U':
            printf("%c is vowel",ltr);
            break;
        default:
            if (isalpha(ltr))
                printf("%c is a consonant",ltr);
            else if (isdigit(ltr))
                printf("It is digit");
            else
                printf("It is special character");
            break;


    }
}
main(){
    char letter;
    printf("Enter the letter:");
    scanf("%c",&letter);
    check_for_vowel(letter);
}
