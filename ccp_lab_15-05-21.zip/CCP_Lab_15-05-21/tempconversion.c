#include <stdio.h>
#include <conio.h>
int main(){
    float faran,celci;
    printf("Enter the temp in fahrenheit:");
    scanf("%f",&faran);
    celci=(faran-32)*5/9;
    printf("Temp in celcius is: %.2f",celci);
    return 0;

}
