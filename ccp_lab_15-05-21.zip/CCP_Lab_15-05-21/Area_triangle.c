//C program to calculate area of triangle
#include<stdio.h>
#include<math.h>
//main program
main(){
    float a,b,c,s,area;
    printf("Enter the sides of triangle:");
    scanf("%f %f %f",&a,&b,&c);
    s=(a+b+c)/2;
    area=sqrt((s*(s-a)*(s-b)*(s-c)));
    printf("Area:%f",area);
    return 0;
}
