#include<stdio.h>
int sum_square_odd(n){
    int i,sum=0,init=1;
    for(i=1;i<=n;i++){
        sum=sum+(init*init);
        init=init+2;
    }
    return sum;
}

main(){
    int n,Sum;
    printf("Enter the n value:");
    scanf("%d",&n);
    Sum=sum_square_odd(n);
    printf("Sum=%d",Sum);
}
