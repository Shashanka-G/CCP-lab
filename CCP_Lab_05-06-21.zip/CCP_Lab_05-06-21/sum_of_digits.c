#include<stdio.h>
int sum_of_digits(int a){
    int sum=0,remainder;
    while(a!=0){
        remainder=a%10;
        sum=sum+remainder;
        a=a/10;
    }
    return sum;
}

main(){
    int num,sum;
    printf("Enter the number:");
    scanf("%d",&num);
    sum=sum_of_digits(num);
    printf("The sum of the digits  in %d is %d",num,sum);
}
