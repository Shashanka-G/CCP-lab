#include<stdio.h>
void print_even(int m,int n){
    int i;
    for(i=m;i<=n;i++){
        if (i%2==0)
            printf("%d \n",i);
        else
            continue;

    }
}

main(){
    int i,m,n;
    printf("Enter the first number:");
    scanf("%d",&m);
    printf("Enter the second number:");
    scanf("%d",&n);
    print_even(m,n);
}
